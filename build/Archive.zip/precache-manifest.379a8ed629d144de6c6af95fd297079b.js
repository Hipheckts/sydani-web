self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "42848d966e05798188e944db87b807be",
    "url": "/index.html"
  },
  {
    "revision": "5c724a05ad232a61d4f1",
    "url": "/static/css/main.1a07c54e.chunk.css"
  },
  {
    "revision": "89ee43db4810940c90d9",
    "url": "/static/js/2.68091f1d.chunk.js"
  },
  {
    "revision": "ffa35a34964860fdc97ed79ca9abd27c",
    "url": "/static/js/2.68091f1d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5c724a05ad232a61d4f1",
    "url": "/static/js/main.7b2e6c56.chunk.js"
  },
  {
    "revision": "f05397f185c909680e12",
    "url": "/static/js/runtime-main.35df8985.js"
  },
  {
    "revision": "41e8dead03fb979ecc23b8dfb0fef627",
    "url": "/static/media/Poppins-Regular.41e8dead.ttf"
  },
  {
    "revision": "72f2628e45e0233d0791423503014cec",
    "url": "/static/media/h-post.72f2628e.png"
  }
]);